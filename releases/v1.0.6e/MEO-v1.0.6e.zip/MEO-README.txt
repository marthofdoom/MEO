marth's Enchanting Overhaul (MEO)
=================================
Socketable, leveling enchantment gems.

RUNNING THE PATCHER (required once, and again after any load-order change)
-----------------------------------------------------------------------------
MEO adapts itself to YOUR load order — nothing is hardcoded. That work is done
by the MEO patcher for SYNTHESIS. It:
  * replaces the enchanting perk tree's crafting perks with MEO's gem perks,
  * derives the gem calibration for your list and writes it to
    SKSE/Plugins/MEO/meo_calibration.json — WITHOUT THIS FILE, LOOT
    CONVERSION DOES NOTHING IN GAME.

MEO ships no executable of any kind. If you are following an older guide that
mentions "MEO.Installer.exe", that path is retired — use Synthesis.

SETUP:
  1. Install this mod and enable it (left pane) + MEO.esp (right pane).
  2. In Synthesis, add the MEO patcher:
       Git Repository -> https://github.com/marthofdoom/MEO
     Synthesis builds it from source; leave the default branch/versioning.
  3. Run the Synthesis group. Enable the patcher's output plugin in your load
     order (right pane), AFTER any other enchanting overhaul.

DID IT WORK? Check that this file now exists in your MEO mod folder (or your
Synthesis output, depending on your setup):
  SKSE/Plugins/MEO/meo_calibration.json      <- the important one
In game, the SKSE log (Documents/My Games/.../SKSE/MEO.log) should say
"calibration: N family recipe(s), M conversion(s) loaded" — not
"no calibration file".

If MEO's perks do not appear in the enchanting tree, MEO.log will say so and
fall back to granting them by Enchanting skill; that means another enchanting
overhaul is overriding the tree — load MEO's patch output after it.
