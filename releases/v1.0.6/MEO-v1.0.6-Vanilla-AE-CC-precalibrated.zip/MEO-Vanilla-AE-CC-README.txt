MEO — Vanilla + Anniversary Edition + Creation Club (pre-calibrated)
====================================================================
OPTIONAL FILE. Lets you SKIP Synthesis if your load order is PURE vanilla +
Anniversary Edition + Creation Club — i.e. no mods that add enchanted gear.

It's a ready-made calibration + enchanting-perk-tree patch for a base Skyrim SE
(AE) install with Creation Club content — the exact result Synthesis would
produce for that load order, pre-built so you don't have to run anything.

INSTALL (after the main MEO mod):
  1. Install the main MEO mod, then install this optional file over it.
  2. Enable BOTH  MEO.esp  and  "MEO - Patch.esp"  in your plugin list.
  3. Play. No Synthesis, no installer to run.

Contains:
  MEO - Patch.esp                        (rewrites the enchanting perk tree)
  SKSE/Plugins/MEO/meo_calibration.json  (gem magnitudes + loot conversion,
                                          5392 vanilla/AE/CC conversions)

USE SYNTHESIS INSTEAD IF you run ANY mod that adds enchanted weapons/armor
(Requiem, Immersive Armors, Wintersun, big overhaul lists, etc.). Those add loot
this pre-built file can't know about — Synthesis calibrates to YOUR actual list.
This optional file covers vanilla + AE + Creation Club ONLY.
